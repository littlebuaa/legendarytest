A general framework to help to build factory test stations 
by tuo.de.li@gmail.com

It contains: 
basic function of communication with different test equipement and device (BK meter, Fluke, etc.) through different protocol (UART, telnet).

Simple interaction way (for operator) by colored printing.

Standard log generation.

===============================================
use "python setup.py sdist" to generate the tar.gz packge.